# tycho-terminal-webapp

This is a WIP vulnerable webapp for an upcoming Azure Lab. Handle with care, this is intentionally very vulnerable.
