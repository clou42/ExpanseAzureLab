export async function getDocking(req, res) {
  res.render("pages/docking", { title: "Docking Queue" });
}
